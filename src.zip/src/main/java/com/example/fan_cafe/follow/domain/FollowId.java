package com.example.fan_cafe.follow.domain;

import jakarta.persistence.Embeddable;

import java.io.Serializable;

@Embeddable
public class FollowId implements Serializable {
    private Long followerId;
    private Long followingId;
}
